/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectthree;

/**
 *
 * @author ogachikelvin && briamassey
 */
public class Business extends Economy{
    private String snacks;
    
    
    public Business(){
     setPrice(450);
     super.setTicketclass("Business");
    }

    /**
     * @return the snacks
     */
    public String getSnacks() {
        return snacks;
    }

    /**
     * @param snacks the snacks to set
     */
    public void setSnacks(String snacks) {
        this.snacks = snacks;
    }
    
    @Override
  public String toString(){
    String X = "";
    X= X+ super.toString()+getSnacks()+"\n";
            return X;
  }
  
  
}